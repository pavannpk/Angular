export interface ICustomer {
  Name: string,
  Picture: string,
  Format: string,
  Cost: number,
  Size: string
}
